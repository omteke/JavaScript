//Array,function,object declaration
let numbers = [1,2,3,4,5]
console.log(numbers)

function add(a,b){
    sum = a+b
    return sum;
}

sum_of_two_numbers = add(5,5);
console.log(sum_of_two_numbers) 

let student = {
    name : "om teke",
    age : 20,
    course : "javascript"
}
console.log(student)
console.log(student.age)